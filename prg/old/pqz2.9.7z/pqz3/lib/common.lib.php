<?php

function print_pre($obj) {
    /*
     * Print all the content of a variable with pre 
     */
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
}




