Data Directory
===

- bin : all program to genertate csv file ( or to convert from other sources to csv)
- conf : all configuration (ex congratulation list urls file, .... ) 
- csv : all csv quiz
- ini : all quiz configuration
- src : all source to generate csv file (e.g. ods file ... )


