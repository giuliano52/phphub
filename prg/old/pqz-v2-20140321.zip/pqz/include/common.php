<?php

/*
 * Copyright (C) 2014 test01
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

function print_pre($obj) {
    /*
     * Print all the content of a variable with pre 
     * 
     */
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
}

function task_store_answers() {
    // TODO CHECK input
    foreach ($_REQUEST as $key => $val) {
        if (substr($key, 0, 2) == "q_") {
            $id = (int) substr($key, 2);
            $_SESSION['quiz'][$id]["answered_question"] = $val;
        }
    }
}

function check_all_answer() {
    $all_answer = true;
    foreach ($_SESSION['quiz'] as $question) {
        if (!isset($question['answered_question'])) {
            $all_answer = false;
        }
    }
    return $all_answer;
}

function inizialize_quiz_conf($xml_file, $base_src_path) {

    $quiz = new pqz();
    $quiz->configuration['base_src_path']['value'] = $base_src_path;
    $quiz->read_quiz_conf($xml_file);

    // change the values of the configuration from REQUEST
    foreach ($_REQUEST as $key => $single_request) {
        if (isset($quiz->configuration[$key]['changable']) && ($quiz->configuration[$key]['changable'] == true)) {
            $quiz->configuration[$key]['value'] = filter_input(INPUT_GET, $key, FILTER_SANITIZE_FULL_SPECIAL_CHARS);
          
        }
    }
    $_SESSION['quiz_conf'] = $quiz->configuration;
}

function inizialize_quiz_question() {
    $quiz = new pqz();
    $quiz->configuration = $_SESSION['quiz_conf'];
    $quiz->generate_question();
    $_SESSION['quiz'] = $quiz->quiz_questions;
}


function quiz_check_answer() {
    $num_correct_answer = 0;

    foreach ($_SESSION['quiz'] as $key => $data_single_quiz) {
        $all_right_question = array();
        foreach ($data_single_quiz['all_correct_answer'] as $single_correct_answer) {
            $all_right_question[] = trim(strtoupper($single_correct_answer));
        }
        $answered_question = trim(strtoupper($data_single_quiz["answered_question"]));
        if (in_array($answered_question, $all_right_question)) {
            $_SESSION['quiz'][$key]['answer_is_correct'] = TRUE;
            $num_correct_answer++;
        } else {
            $_SESSION['quiz'][$key]['answer_is_correct'] = FALSE;
        }
    }
    $_SESSION['quiz_conf']['num_correct_answer'] = $num_correct_answer;
}

function choose_cvs_entry($csv_file) {
    /* Return a random element from a csv_file */
    $csv_array = csv_to_array($csv_file);

    $id = array_rand($csv_array);

    //print ($id ."-".count($csv_array));
    return $csv_array[$id]['url'];
}

function csv_to_array($filename = '', $delimiter = ';') {
    // convert a csv file to an array

    if (!file_exists($filename) || !is_readable($filename)) {
        return FALSE;
    }

    $header = NULL;
    $data = array();
    if (($handle = fopen($filename, 'r')) !== FALSE) {
        while (($row = fgetcsv($handle, 1000, $delimiter)) !== FALSE) {
            if (empty($row)) {
                continue;
            }
            if (!$header) {
                $header = $row;
            } else {
                $data[] = array_combine($header, $row);
            }
        }
        fclose($handle);
    }
    return $data;
}

function cmd_insert_field_into_sql() {
    $quiz = new pqz();
    $question_fields=$quiz->question_fields;
    global $upload_sqlite_file;

    $allowed_field = array("question", "correct_answer", "wrong_answer", "difficult_level", "response_type", "tags");
    $myinput = array();
    foreach ($allowed_field as $single_field) {
        $myinput[$single_field] = isset($_REQUEST[$single_field]) ? $_REQUEST[$single_field] : "";
    }

    $db_filename = $upload_sqlite_file;

    if (!file_exists($db_filename))
        die("File db -$db_filename- not found");


    $db = new SQLite3($db_filename);
    $query = 'INSERT INTO quiz 
					("quiz_name","' . implode('","', $allowed_field) . '") 
			  VALUES 
					("upload",:' . implode(',:', $allowed_field) . ')';
    $stmt = $db->prepare($query);
    foreach ($allowed_field as $single_field) {
        $stmt->bindValue(":$single_field", $myinput[$single_field]);
    }
    $result = $stmt->execute();

    //	$result = $db->exec($query) or die("query: $query failed");
    if ($result) {
        emit_query_ok();
    } else {
        die("query: $query failed");
    }
}
