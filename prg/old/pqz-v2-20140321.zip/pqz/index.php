<?php

session_start();

$version = "2.20140130.01";
$debug = false;



$base_src_path = 'data/src/';
$base_xml_path = 'data/xml/prod/';
$base_img_path = 'data/img/';
$upload_sqlite_file = "data/src/db/upload.sqlite";


if (substr($_SERVER["HTTP_HOST"], 0, 7) != '192.168') {
    // production
    $debug = false;
    $base_xml_path = 'data/xml/prod/';
}


require_once('include/pqz.class.php');
require_once('include/common.php');
require_once('include/emit.php');
include_once('include/spreadsheet-reader/SpreadsheetReader.php');





$xml_file = isset($_SESSION['quiz_configuration']) ? $_SESSION['quiz_configuration'] : $base_xml_path . 'generici/upload.xml';

$task = isset($_GET['task']) ? filter_input(INPUT_GET, 'task', FILTER_SANITIZE_ENCODED) : "choose_quiz";
$question_n = isset($_GET['starting_question']) ? filter_input(INPUT_GET, 'starting_question', FILTER_SANITIZE_ENCODED) : 0;
$quiz_dir = isset($_GET['quiz_dir']) ? filter_input(INPUT_GET, 'quiz_dir', FILTER_SANITIZE_FULL_SPECIAL_CHARS) : $base_xml_path;
$xml_file = isset($_GET['quiz_configuration']) ? filter_input(INPUT_GET, 'quiz_configuration', FILTER_SANITIZE_FULL_SPECIAL_CHARS) : $xml_file;





if (!isset($_SESSION['quiz'])) {
    inizialize_quiz_conf($xml_file, $base_src_path);
    inizialize_quiz_question();
}

emit_header();

switch ($task) {
    case "reset":
        unset($_SESSION['quiz']);
        inizialize_quiz_conf($xml_file, $base_src_path);
        inizialize_quiz_question();
        emit_quiz();
        break;
    case "restart_quiz":
        inizialize_quiz_question();
        emit_quiz();
        break;
    case "go_quiz":
        $question_n = min(count($_SESSION['quiz']) - 1, max($question_n, 0));
        emit_quiz($question_n);
        break;
    case "store_answer":
        $question_n = min(count($_SESSION['quiz']) - 1, max($question_n, 0));
        task_store_answers();
        emit_quiz($question_n);
        break;
    case "results":
        emit_results();
        break;
    case "choose_quiz":
        emit_choose_quiz($quiz_dir);
        break;
    case "destroy_all":
        unset($_SESSION);
        break;
    case "choose_quiz_advanced":
        emit_choose_quiz_advanced();
        break;
    case "insert_data_into_quiz":
        emit_insert_data_into_quiz();
        break;
    case "insert_field":
        cmd_insert_field_into_sql();
        emit_insert_data_into_quiz();
        break;
    default :
        die("TASK: <b>$task</b> unrecognized");
}


emit_restart();

emit_footer();

$_SESSION['quiz_configuration'] = $xml_file;

if ($debug) {
    echo '<h3>Debug SESSION</h3>';
    print_pre($_SESSION);
}
?>



