<?php
/* Author: GD
 * Created: 20131129
 * Modified: 20140115
 *
 *
 */
session_start(); 
require_once('./conf.php');
require_once('./include/quiz_emit_inc.php');
require_once('./include/quiz_fnc_inc.php');
require_once('./include/common_inc.php');
 
// ------------------------- MAIN --------------------

$cmd = isset($_REQUEST['cmd']) ? test_input($_REQUEST['cmd']) : "None";

if (!isset($_SESSION['data_quiz'])) {
	initialize_session_with_default() ;
	request_to_session();
	cmd_inizialize_quiz();
}

switch($cmd) {
	case "reset_quiz":
		emit_redirect();
		session_destroy();
	break;
	case "results":
		emit_header();
		emit_result();
		emit_footer();
	break;
	case "choose_quiz_advanced":
		emit_header();
		emit_choose_quiz_advanced();
		emit_footer();
	break;
	case "insert_field":
		cmd_insert_field();
	case "insert_data_into_quiz":
		emit_header();
		emit_insert_data_into_quiz();
		emit_footer();
	break;
	
	case "store_answers":
		cmd_store_answers();
	case "go_quiz":
		emit_header();
		$starting_question = (int)(isset($_REQUEST['starting_question']) ? test_input($_REQUEST['starting_question']) : 0);
		cmd_quiz($starting_question);
		emit_footer();
	break;
	case "choose_quiz":
	default:
		session_destroy();
		emit_header();
		emit_choose_quiz();
		emit_footer();
	break;

}


if($debug == TRUE) {
	print_pre($_SESSION);
	echo '<hr>';
	print_pre($_REQUEST);

}
 
?>
