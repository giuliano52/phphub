﻿Quiz
===
CSV File must have for the first row the following field
we should use all ascci character, for particuale char use the html encoding;

- question	: The question that will be presented
- correct_answer	: The correct answer
- id (optional)	: an unique identificative of the question
- wrong_answer (optional)	: If this filed is present this anwer will be forced to be one on the option in the answer (diffrent   answer are separated by | ) put the most likely answer at the beggining of the list
- difficult_level (optional)(int)	 : Number that identify the difficulties of the question (0 easiest 100 hardest) by default 10:very easy 20:easy 30:normal 40: difficult 50: very difficult
- response_type (optional)	: options -> multiple options ; not_null -> anything not null; int -> integer ; options_5: options with 5 possible answer
- tags (optional) : cathegorize the question in different tag (separated by | )

#HISTORY
##V 1.0
- Possibility to implement specific configuration from XML file
- read both csv and ods
- choose sheets inside ods (after filename use # symbol ) 
- choose quiz from available
- option to reverse question from answer


#TODO
- Aggiungere i risoltati con frozen

##v1.1 
- aggiungere tempo di questionario
- implementare: response_type  not_null, int, boolean
X implementare tag nelle domande (es domande solo con particolari tag)
- import da excel

##v2.0
- implementare eventuale collegamento con DB
X Import quiz da db
- inserire la memorizzazione delle risposte giuste in modo da chiedere solo quelle che non si sanno
- inserire template 

##v3.0
- export in PDF
- Implement modules


#BUG
- migliorare la navigazione tra i quiz
