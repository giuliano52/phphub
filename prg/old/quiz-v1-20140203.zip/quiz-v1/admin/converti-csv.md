#per convertire i csv
https://github.com/colonelqubit/libreconverter
```
libreconverter.py nazioni-del-mondo.ods:capitali capitali.csv
# da verificare
sed -i 's/,/;/g' FILENAME
```
