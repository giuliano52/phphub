﻿<?php

function ods_to_array($filename,$sheet_name=0) {
	// extract values from an ods file to an array
	// using SpreadsheetReader.php
	$out = array();
	
	include_once("include/spreadsheet-reader/SpreadsheetReader.php");
	$Spreadsheet = new SpreadsheetReader($filename);
	$Sheets = $Spreadsheet -> Sheets();

	$sheet_index = array_search($sheet_name, $Sheets);

	$Spreadsheet -> ChangeSheet($sheet_index);
	foreach ($Spreadsheet as $Key => $Row) {
		$out[] = $Row;
	}
	
	
	$out = associate_first_row($out);
	
	return $out;
}



function csv_to_array($filename='', $delimiter=';'){
	// convert a csv file to an array

    if(!file_exists($filename) || !is_readable($filename))
        return FALSE;

    $header = NULL;
    $data = array();
    if (($handle = fopen($filename, 'r')) !== FALSE)
    {
        while (($row = fgetcsv($handle, 1000, $delimiter)) !== FALSE)
        {
            if (empty($row)) continue;
            if(!$header)
                $header = $row;
            else
                $data[] = array_combine($header, $row);
        }
        fclose($handle);
    }
    return $data;
}

function sqlite_to_array($db_filename,$quizname="",$quiz_tags="") {
/* import a table into an array */
	global $question_fields;
	
	$quizname = filter_var($quizname,FILTER_SANITIZE_STRING);
	$out = array();
	$i =0 ;
	$db = new SQLite3($db_filename);
	
	$query = 'SELECT '.implode(',',array_keys($question_fields) ).' FROM quiz WHERE quiz_name LIKE "%'.$quizname .'%"';
	$result = $db->query($query) or die("query: $query failed");
	while($res = $result->fetchArray()){
		foreach ($question_fields as $field=>$filter_type) {
			$out[$i][$field] = $res[$field];
		}
		$i++;
          } 
	return $out;

}


function test_input($data) {
	// clean input 
//	echo "$data ".mb_detect_encoding($data)." -->\n";
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
//	echo "$data ".mb_detect_encoding($data)."<br />\n";
	return $data;
}

function choose_cvs_entry($csv_file) {
	/* Return a random element from a csv_file */
	$csv_array = csv_to_array($csv_file);
	
	$id = array_rand($csv_array);
	
	//print ($id ."-".count($csv_array));
	return $csv_array[$id]['url'];
}

function choose_file($dir) {
	// chose a random file from a directory
	$a_dir = array();
	if ($handle = opendir($dir)) {
    while (false !== ($entry = readdir($handle))) {
        if ($entry != "." && $entry != "..") {
            $a_dir[] = $entry;
        }
    }
    closedir($handle);
	}
	return $a_dir[array_rand($a_dir)];
}
 
function associate_first_row($array_in) {
//	return an array with the keys taken from the first row
	$out = array();
	$ident = array_shift($array_in);
	foreach ($array_in as $key_r => $row)
		foreach ($row as $key_c => $cell)
			$out[$key_r][$ident[$key_c]]=$cell;

	return $out;
}

function print_pre($obj) {
	echo "<pre>";print_r($obj); echo "</pre>";
}
?>
