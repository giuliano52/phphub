﻿<?php
/* Author: GD
 * Created: 20131129
 * Modified: 20140103
 *
 *
 */

 
function initialize_session_with_default() {

	global $configuration_array;
	foreach ($configuration_array as $key=>$value) {
		$_SESSION[$key]=$value['value'];
		}

}

 
function cmd_inizialize_quiz() {
	
	$data_quiz_src = get_data_from_source();

	
	if (strtoupper($_SESSION['default_randomize_question']) == "TRUE") 
		shuffle($data_quiz_src);

	
	// if $_SESSION['reverse_question'] = true switch question to answer
	$question_string = $_SESSION['reverse_question']=="TRUE" ? 'correct_answer' : 'question';
	$correct_answer_string = $_SESSION['reverse_question']=="TRUE" ?  'question' : 'correct_answer';
	
	
	
	// find all possible answer for the test
	$all_possible_answer = array();
	foreach ($data_quiz_src as $single_quiz) {
		$difficult_level = isset($single_quiz['difficult_level']) ? $single_quiz['difficult_level'] : 1 ;
		$all_correct_answer = explode('|', $single_quiz[$correct_answer_string]);
		if (($difficult_level >= $_SESSION['min_diffucult_level']) && ($difficult_level <= $_SESSION['max_diffucult_level']))
			$all_possible_answer[] = $all_correct_answer [0];
	}
	

	$data_quiz = array();
	// calculate the number of question 
	
	if ($_SESSION['Max_question_total'] > 0) {
		$num_question = min(count($data_quiz_src),$_SESSION['Max_question_total']) ;
		}
	else  {
		$num_question = count($data_quiz_src);
		}
	$_SESSION['Num_question_total'] = $num_question;
	
	
	// insert data from csv to $data_quiz
	$question_id = 0;



	foreach ($data_quiz_src as $single_quiz) {

		$difficult_level = isset($single_quiz['difficult_level']) ? $single_quiz['difficult_level'] : 1 ;
		if (($difficult_level >= $_SESSION['min_diffucult_level']) && ($difficult_level <= $_SESSION['max_diffucult_level'])) {

			// Add item to $data_quiz
			
			// id of the question
			$data_quiz[$question_id]['id'] = isset($single_quiz['id']) ? $single_quiz['id'] : "NONE" ;
			
			// add question:
			$possible_question = isset($single_quiz[$question_string]) ? explode('|',$single_quiz[$question_string]) : "NONE" ;
			
			$data_quiz[$question_id]['question'] = $possible_question[array_rand($possible_question)];
			
			$data_quiz[$question_id]['correct_answer'] = isset($single_quiz[$correct_answer_string]) ? $single_quiz[$correct_answer_string] : "NONE" ;
			$data_quiz[$question_id]['response_type'] = isset($single_quiz['response_type']) ? $single_quiz['response_type'] : "text" ;
			
			// find all correct answer 
			$data_quiz[$question_id]['all_correct_answer'] = explode('|', $single_quiz[$correct_answer_string]);
			
			shuffle($all_possible_answer);
			
			// add the first correct answer to $possible_answer
			$possible_answer = array($data_quiz[$question_id]['all_correct_answer'][0]);
			
			//  add wrong answer to $possible_answer from input data
			if (isset($single_quiz["wrong_answer"])) {
				$possible_wrong_answer = explode('|', $single_quiz["wrong_answer"]);
				$possible_answer = array_merge($possible_answer,$possible_wrong_answer);
			}
			
			//  add random wrong answer to $possible_answer
			$possible_answer = array_merge($possible_answer,$all_possible_answer);
			
			// eliminate duplicates
			$possible_answer = array_unique($possible_answer);
			
			//remove eventually emtpy element
			$possible_answer = array_filter($possible_answer);
			
			//get only the correct number of elements:
			$possible_answer = array_slice($possible_answer,0,$_SESSION['Num_options']) ;
			
			// shuffle all data:
			shuffle($possible_answer);
			
			// Store all in the $data_quiz 
			$data_quiz[$question_id]["possible_answer"]= $possible_answer;
			
			// add id of the correctanswer to correct answer if the answer_type is 'options' 
			if ($data_quiz[$question_id]['response_type'] == "options") {
				$key = array_search($data_quiz[$question_id]['all_correct_answer'][0], $possible_answer); 
				$data_quiz[$question_id]['all_correct_answer'][] = $key;
			}
			
			
			
			$question_id ++;
		}
	}
		
	$_SESSION['data_quiz'] = array_slice($data_quiz,0,$_SESSION['Num_question_total']);
	//echo "<pre>";print_r($_SESSION);echo "</pre>";

	// return $data_quiz;
}

function cmd_quiz($starting_question=0) {
	
	$next_starting_question = $starting_question + $_SESSION['Num_question_per_page'];
	$previous_starting_question = max($starting_question - $_SESSION['Num_question_per_page'],0);

	if (isset($_REQUEST['Nav']) && $_REQUEST['Nav'] == "Precedente") 
		$starting_question = $previous_starting_question;
	elseif (isset($_REQUEST['Nav']) && $_REQUEST['Nav'] == "Prossimo") 
		$starting_question = $next_starting_question;
	// verifico che lo starting question stia tra 0 e il numero totale di domande
	if ($starting_question < 0) 
		$starting_question = 0;
	if ($starting_question > $_SESSION['Num_question_total']-1) 
		$starting_question = $_SESSION['Num_question_total']-1;	

	
	$data_quiz = $_SESSION['data_quiz'];
	//check if all question have an answer
	$all_answered = TRUE;
	for($id_question = 0; $id_question < count($data_quiz) ; $id_question++) {
		if(!isset($data_quiz[$id_question]["answered_question"])) 
			$all_answered = FALSE;
	}
		
	emit_quiz_header();
	
	if ($_SESSION['Num_question_per_page'] > 0) 
		$num_question = min(count($data_quiz),$_SESSION['Num_question_per_page']) ;
	else 
		$num_question = count($data_quiz);
	
	$tab_index = 1;
	for($question_index = $starting_question; $question_index < $num_question+$starting_question; ++$question_index) {
		emit_question($data_quiz[$question_index],$question_index,$tab_index);
		$tab_index ++;
	}
	emit_quiz_footer($starting_question,$all_answered);
}


function cmd_store_answers() {
	foreach($_REQUEST as $key=>$val) {
		if(substr($key,0,2)=="q_") {
			$id = (int)substr($key,2) ;
			$_SESSION['data_quiz'][$id]["answered_question"] = test_input($val);
		}
		
	}
	
}


function quiz_check_answer() {
	$num_correct_answer = 0;

	foreach ($_SESSION['data_quiz'] as $key => $data_single_quiz) {
		$all_right_question = array();
		foreach ($data_single_quiz['all_correct_answer'] as $single_correct_answer) {
			$all_right_question[] = trim(strtoupper($single_correct_answer));
		}
		$answered_question = trim(strtoupper($data_single_quiz["answered_question"]));
		if (in_array($answered_question , $all_right_question)) {
			$_SESSION['data_quiz'][$key]['answer_is_correct'] = TRUE;
			$num_correct_answer++;
			}
		else
			$_SESSION['data_quiz'][$key]['answer_is_correct'] = FALSE;
	}
	$_SESSION['num_correct_answer']= $num_correct_answer;
	
}

function read_xml_quiz_conf($xml_file) {
	// read xml from file and overrite default _session values
	if(!file_exists($xml_file)) 
		die ("File xml -$xml_file- not found");
	$xml = simplexml_load_file($xml_file);
	foreach($xml->children() as $child) {
		//echo $child->getName() . ": " . $child . "<br>";
		$_SESSION[$child->getName()] = (string)$child;
	}
}

function check_array_quiz($data_quiz_src) {
// verify that all row of the input array has the correct field to be processed

	$array_out = array();
	$id = 0;
	foreach ($data_quiz_src as $single_row) {
		if(!empty($single_row['question']) && !empty($single_row['correct_answer'] ) ) {
			$array_out[$id]['question'] = $single_row['question'];
			$array_out[$id]['correct_answer'] = $single_row['correct_answer'];
			$array_out[$id]['id'] =  (!empty($single_row['id'])) ? $single_row['id'] : $id;
			$array_out[$id]['wrong_answer'] =  (!empty($single_row['wrong_answer'])) ? $single_row['wrong_answer'] : "";
			$array_out[$id]['difficult_level'] =  (isset($single_row['difficult_level'])) ? $single_row['difficult_level'] : "1";
			$array_out[$id]['response_type'] =  (!empty($single_row['response_type'])) ? $single_row['response_type'] : $_SESSION['default_response_type'];			
		
			$id ++;
		}
		
	}
	return $array_out;
}


function request_to_session() {
	global $quiz_dir;
	global $configuration_array;
	$quiz_configuration = isset($_REQUEST['quiz_configuration']) ? test_input($_REQUEST['quiz_configuration']) : "";
	$dir = isset($_REQUEST['quiz_dir']) ? test_input($_REQUEST['quiz_dir']) : "";
	if(!empty($quiz_configuration)) {
		if (substr($quiz_configuration,0,5) != "data/") {
			$quiz_configuration = $quiz_dir."/".$quiz_configuration;
		}
		$_SESSION['quiz_configuration'] = $quiz_configuration;
	}
		// read specific xml conf;
	if (isset($_SESSION['quiz_configuration'])) {
		if (file_exists($_SESSION['quiz_configuration'])) {
			read_xml_quiz_conf($_SESSION['quiz_configuration']);	
		} 
		else {
			echo "The file ".$_SESSION['quiz_configuration']." does not exist";
		}
	}
	
	foreach ($configuration_array as $key=>$single_configuration) {
		if ($single_configuration['changable']) {
			if(isset($_REQUEST[$key])) {
				$_SESSION[$key]=$_REQUEST[$key];
				
			}
		}
	}
	
		
	
	
}

function get_possible_quiz($dir) {
		// chose a random file from a directory
	$a_dir = array();
	$a_files=array();
	
	$scanned_directory = array_diff(scandir($dir), array('..', '.'));

	foreach($scanned_directory as $entry) {
			if (is_dir("$dir/$entry")) {
			
			$a_dir[$entry] = "dir";
		}
        elseif (strtolower(pathinfo($entry, PATHINFO_EXTENSION)) == 'xml') {
            $a_files[$entry] = "file";
        }
	}
	
	

	$a_out = array_merge($a_dir,$a_files);
	return $a_out;
}

function get_data_from_source() {
/* Get data from source imput (csv file, ods file, db .... ) 
	
*/
	$input_source = $_SESSION['quiz_name'];
	
	// Separate filename from sheets name
	$file_data = explode("#",$input_source);
	$quiz_filename = $file_data[0];
	$quiz_tags = $_SESSION['tags'];

	if(!file_exists($quiz_filename)) 
		die ("File -$quiz_filename- not found");
		
	$ext = pathinfo($quiz_filename, PATHINFO_EXTENSION);
	if ( strtoupper($ext) == "CSV") {
		// is a 
		$data_quiz_src=csv_to_array($quiz_filename);
		if (!empty($quiz_tags)) 
			$data_quiz_src = filter_quiz_tags($data_quiz_src,$quiz_tags);
	}
	elseif ( strtoupper($ext) == "ODS") {
		$quiz_sheet = isset($file_data[1]) ? $file_data[1] : "";
		$data_quiz_src=ods_to_array($quiz_filename,$quiz_sheet );
		if (!empty($quiz_tags)) 
			$data_quiz_src = filter_quiz_tags($data_quiz_src,$quiz_tags);
	}
	elseif ( strtoupper($ext) == "SQLITE") {
		$quiz_name = isset($file_data[1]) ? $file_data[1] : "";
		$data_quiz_src = sqlite_to_array($quiz_filename,$quiz_name,$quiz_tags);
		
	}	
	else {
		die ("Unkown format");
	}
	$data_quiz_src=check_array_quiz($data_quiz_src);

	return $data_quiz_src;
}
 
 
function cmd_insert_field() {
	
	global $question_fields;
	global $upload_sqlite_file;
		
	$allowed_field = array("question","correct_answer","wrong_answer","difficult_level","response_type","tags");
	$myinput = array();
	foreach ($allowed_field as $single_field) {
		$myinput[$single_field] = isset($_REQUEST[$single_field]) ? $_REQUEST[$single_field] : "";
	}
	
	$db_filename=$upload_sqlite_file;
	
	if(!file_exists($db_filename)) 
		die ("File db -$db_filename- not found");
	
		
	$db = new SQLite3($db_filename);
	$query = 'INSERT INTO quiz 
					("quiz_name","'.implode('","',$allowed_field).'") 
			  VALUES 
					("upload",:'.implode(',:',$allowed_field).')';
		$stmt = $db->prepare($query);
		foreach ($allowed_field as $single_field) {
			$stmt->bindValue(":$single_field", $myinput[$single_field]);
			}
		$result = $stmt->execute();
		
	//	$result = $db->exec($query) or die("query: $query failed");
	if ($result) {
		emit_query_ok();
	}
	else {
		die("query: $query failed");
	}
		
}

function filter_quiz_tags($data_quiz_src,$tags) {
	// filter the quiz data with specified tags
	$out = array();
	foreach ($data_quiz_src as $single_quiz) {
		if (stripos($single_quiz['tags'],$tags) !== false) 
			$out[] = $single_quiz;
	}
	return $out;

}

?>
