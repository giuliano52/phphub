﻿<?php
/* Author: GD
 * Created: 20131129
 * Modified: 20131227
 *
 *
 */
 
function emit_question($single_quiz_data,$question_index,$tab_index=1) {
	$answer = isset($single_quiz_data['answered_question']) ? $single_quiz_data['answered_question'] : "";
	echo "<tr><td>\n";
	echo emit_question_status($question_index);
	echo "</td>\n";
	echo "<td>\n";
	echo $single_quiz_data["question"];
	echo "</td>\n";
	echo "<td class=\"possible_answer\">\n";
	$response_type  = isset($single_quiz_data['response_type']) ? $single_quiz_data['response_type'] : $_SESSION['default_response_type'];
	if ($response_type == "options") {
		// Multiple Options 
		foreach ($single_quiz_data['possible_answer'] as $key => $possible_answer) {
			$checked = ($answer == $possible_answer) ? " checked " : "";
			echo "\t";
			echo '<input type="radio" name="q_'.$question_index.'" value="'.$key.'" '.$checked.'>';
			echo $possible_answer;
			echo "<br>\n"; 
		}
	}
	else {
		$possible_answer = isset($single_quiz_data['answered_question']) ? $single_quiz_data['answered_question'] : "";
		$opt = "tabindex=$tab_index ";
		if ($tab_index==1)
			$opt .= "autofocus";
		echo "<input type=\"text\" name=\"q_$question_index\" value=\"$possible_answer\" $opt >";
	}
	
	echo "</td></tr>\n";
}

function emit_question_status($question_index) {
	// mostra le domande a cui si è risposto e quelle che mancano
	$content = "<table>\n";
	
	foreach  ($_SESSION['data_quiz'] as $id=>$single_question) {
		if ($id == $question_index) {
			$extra_stle = "outline: thin solid black;";
		}
		else {
			$extra_stle = "";
		}
		$link = "?starting_question=$id&cmd=go_quiz";
		$content .= "<tr style=\"$extra_stle\" class=\"question_status\">\n";
		$content .= "\t<td><a href=\"$link\">".($id+1)."</a></td>";
		$content .= "<td><a href=\"$link\">";
		if (isset($single_question['answered_question'])) {
			$content .= '<img src="data/img/Circle-question-green.png"  />';	
		}
		else {
		
			$content .= '<img src="data/img/Circle-question-yellow.png" />';	
		}
		
		$content .= "</a></td><tr>\n";
	}
	
	$content .= "</table>\n";
	return $content;

}

function emit_header() {
echo '<html>
<head>
<meta charset="UTF-8" />
<link rel="stylesheet" type="text/css" href="quiz.css" />
</head>
<body>
';
echo "<h1>".$_SESSION['title']."</h1>";
}

function emit_quiz_header() {
echo '
<form action="'.htmlspecialchars($_SERVER["PHP_SELF"]).'" method="get">
<input type="hidden" name="cmd" value="store_answers"> 
<table border="1">
';
}

function emit_quiz_footer($starting_question,$all_answered) {
	echo '</table>';
	echo '<input type="hidden" name="starting_question" value="'.$starting_question.'"> ';

	if ($all_answered == TRUE) {
		echo "<br /><br />\n";
		echo "Hai risposto a tutte le domande: Guarda i ";
		echo '<b><a href="'.htmlspecialchars($_SERVER["PHP_SELF"]).'?cmd=results">RISULTATI</a></b>';
	}
	else {
		echo "\n";
	//	echo '<input type="submit" value="Precedente" Name="Nav">';
		echo '<input type="submit" value="Prossimo" Name="Nav">';
		}
	echo "</form>\n";
	
}

function emit_footer() {
	global $version;

	echo '<br /><br />';
	emit_restart();
	echo '<br /><br />';
	echo '<br /><div style="font-size:x-small">Versione :'.$version.'</div>';
	echo "\n</body>\n</html>";
}

function emit_result() {

	quiz_check_answer();
	
	$data_quiz =$_SESSION['data_quiz'];

	$num_question = count($data_quiz);


	echo '<table border="1">';
	echo '<tr ><td>';
	echo '<table border="1">';
	for($question_index = 0; $question_index < $num_question; ++$question_index) {
		if ($data_quiz[$question_index]['response_type'] == "options") {
			$answer = $data_quiz[$question_index]['possible_answer'][$data_quiz[$question_index]["answered_question"]];
		}
		else {
			$answer  = $data_quiz[$question_index]["answered_question"];
		}
		$correct_answer = $data_quiz[$question_index]["all_correct_answer"][0];
		echo '<tr>';
		echo '<td>'.$data_quiz[$question_index]["question"].'</td>';

		if ($data_quiz[$question_index]['answer_is_correct']) {
			// Correct answer
			echo '<td style="background-color:green;">';
			echo $answer;
			echo "</td>\n";

			}
		else {
			// wrong answer
			echo '<td style="background-color:red;">';
			echo "Hai risposto : <b>$answer</b><br />";
			echo "Ma la risposta giusta era: <b>$correct_answer</b><br />";
			echo "</td>\n";
		}
		echo '</tr>';
	}
	echo "</table>\n";
	echo "</td><td style=\"vertical-align:top;\">";
	echo 'hai risposto giusto '.$_SESSION['num_correct_answer'].' su '.$num_question.' domande';
	if($_SESSION['num_correct_answer'] == $num_question) {

		$img = choose_cvs_entry($_SESSION['congratulation_file']);
		echo "<br /><img src=\"$img\" width=\"800\">\n";
		//echo "<br />$img\n";
	}
	emit_restart();
	
	echo "</td></tr>";
	echo "</table>";
}

function emit_restart() {
	$line = isset($_SESSION['quiz_configuration']) ? '?cmd=reset_quiz&quiz_configuration='.$_SESSION['quiz_configuration'] : '?cmd=reset_quiz';
	echo '<br /><A href="'.htmlspecialchars($_SERVER["PHP_SELF"]).$line.'">RICOMINCIA</A>';
	echo '<br /><A href="'.htmlspecialchars($_SERVER["PHP_SELF"]).'?cmd=choose_quiz">CAMBIA QUIZ</A>';
	echo '<br /><A href="'.htmlspecialchars($_SERVER["PHP_SELF"]).'?cmd=insert_data_into_quiz">INSERISCI DOMANDE</A>';
}

function emit_redirect($quiz_name=0) {
	// redirect to home page
	
	$line = !empty($quiz_name) ? "?quiz_configuration=$quiz_name" : "" ;
	$line = '?quiz_configuration='.$_SESSION['quiz_configuration'].'&cmd=go_quiz';
	foreach ($_REQUEST as $key=>$value) {
		if ($key != 'cmd') {
			$line .= "&$key=$value";
		}
	}
	
	echo '<html><head>
	<meta http-equiv="refresh" content="0; url='.htmlspecialchars($_SERVER["PHP_SELF"]).$line.'" />
	</head>
	<body>
	</body>
	</html>';
}

function emit_choose_quiz()  {
	global $quiz_dir;
	
	$dir_requested = isset($_REQUEST['quiz_dir']) ? filter_var($_REQUEST['quiz_dir'],FILTER_SANITIZE_SPECIAL_CHARS) : "";
	$dir = $quiz_dir."/".$dir_requested;
	
	$content = "<table id=\"fancytable\" style=\"width:500px;\">\n";
	$content .="<tr><th>Type</th><th>Quiz Name</th><th>Options</th></tr>";
	$alt =false;
	
	$possible_quiz = get_possible_quiz($dir);
	foreach ($possible_quiz as $entry=>$type) {
			if ($alt) 
				$content .= "<tr>\n";
			else
				$content .= "<tr class=\"alt\">\n";

			if ($type=="dir") {
			
			$content .= "<td><img src=\"data/img/Blue_folder_seth_yastrov_01.png\" ></td>";
			$content .= "<td><A href=\"".htmlspecialchars($_SERVER["PHP_SELF"])."?cmd=choose_quiz&quiz_dir=$dir_requested/$entry\">$entry</A></td>\n";
			$content .= "<td>&nbsp;</td>";
		}
		elseif($type=="file") {
			$filename_without_ext = preg_replace("/\\.[^.\\s]{3,4}$/", "", $entry);
			$content .= "<td>quiz</td>\n";
			$content .= '<td><A href="'.htmlspecialchars($_SERVER["PHP_SELF"])."?cmd=reset_quiz&quiz_configuration=$dir_requested/$entry\">$filename_without_ext</A></td>\n";
			$content .= '<td><A href="'.htmlspecialchars($_SERVER["PHP_SELF"]).'?cmd=choose_quiz_advanced&quiz_configuration='.$dir.'/'.$entry.'">Opzioni Avanzate</A></td>'."\n";
		}
		$content .= "</tr>\n";
		$alt =!$alt;
	}
	$content .= "</table>\n";
	echo $content;
	//return $content;
	
	
}

function emit_insert_data_into_quiz() {
	$content = '';
	$alt = false;
	global $question_fields;
	$content .= '<form action="'.htmlspecialchars($_SERVER["PHP_SELF"]).'" method="get">';
	
	$content .= "<table id=\"fancytable\">\n";
	$content .= "<tr><th width=\"30%\">Field</th><th>Value</th>\n";
	foreach ($question_fields as $field=>$filter_type) {
		if ($field != "id") {
			if ($alt) 
				$content .= "<tr>\n";
			else
				$content .= "<tr class=\"alt\">\n";
			$content .= "<td>";
			if($filter_type['required']) 
				$content .= "<b>".$filter_type['description']." (*) </b>";
			else 
				$content .= $filter_type['description'];
			$content .= "</td>";
			$content .= "<td>";
			$content .= "<input type=\"text\" name=\"$field\" size=\"80\">\n";
			$content .= "</td>";
			$content .= "</tr>\n";
			$alt = !$alt;
		}
	}
	$content .= "</table>\n";
	$content .= '<input type="hidden" name="cmd" value="insert_field"><br>'."\n";
	$content .= '<input type="submit" name="insert_field"><br>'."\n";
	
	$content .= "</form>";
	
	$content .= "Field with asterisk (*) are mandatory";
	echo $content;
	//return $content;
}
 
function emit_choose_quiz_advanced() {

	global $configuration_array;
	$content = "";
	$content .= '<form action="'.htmlspecialchars($_SERVER["PHP_SELF"]).'" method="get">';
	
	$content .= "<table id=\"fancytable\">\n";
	$content .= "<tr><th>Configuration</th><th>Value</th>";
	
	$alt = false;
	
	foreach ($configuration_array as $key => $single_configuration) {
		if ($single_configuration['changable']) {
			if ($alt) 
				$content .= "<tr>\n";
			else
				$content .= "<tr class=\"alt\">\n";
			
			$content .= "<td>";
			$content .= $single_configuration['description'];
			$content .= "</td>";
			$content .= "<td>";
			$value =  $_SESSION[$key];
			$content .= "<input type=\"text\" name=\"$key\" value=\"$value\">";
			$content .= "</td>";
			
			$content .= "</tr>\n";
		$alt = !$alt;
		}
	}
	if (isset($_SESSION['possible_tags'])) {
		if ($alt) 
			$content .= "<tr>\n";
		else
			$content .= "<tr class=\"alt\">\n";
			
		$content .= "<td>Available TAGS</td>";
		$content .= "<td>".$_SESSION['possible_tags']."</td>";
	}
	
	
	$content .= "</table>\n";
	
	$content .= '<input type="hidden" name="cmd" value="reset_quiz"><br>'."\n";
	$content .= '<input type="submit" name="Start Quiz"><br>'."\n";
	$content .= "</form>";
	echo $content;
	//return $content ;
}

function emit_query_ok() {
	echo "Question insert";
}
?>
