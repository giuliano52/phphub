﻿<?php
/* Author: GD
 * Created: 20131129
 * Modified: 20131223
 *
 *  Test single procedures
 */



require_once('./include/common_inc.php');


$arr = ods_to_array_2("data/quiz_strumenti.ods");

print_pre($arr);

 
 
?>
