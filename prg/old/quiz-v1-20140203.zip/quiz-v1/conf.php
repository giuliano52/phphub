﻿<?php

$debug = false;
$version = "1.0.5";
$quiz_dir = 'data/xml';
$quiz_dir = 'data/xml/prod';
$upload_sqlite_file = "data/src/db/upload.sqlite";


if( substr($_SERVER["HTTP_HOST"],0,7)!='192.168') {
	// production
	$debug = false;
	$quiz_dir = 'data/xml/prod';
	$upload_sqlite_file = "data/src/db/upload-altervista.sqlite";
	}

$question_fields = array(
	'id'=>array(
		'description'=>'An id of the question',
		'required'=>false,
		'filter'=>FILTER_SANITIZE_ENCODED,
		),
	'question'=>array (
		'description'=>'Question',
		'required'=>true,
		'filter'=>FILTER_SANITIZE_ENCODED,
		),
	'correct_answer'=>array (
		'description'=>'Correct Answer',
		'required'=>true,
		'filter'=>FILTER_SANITIZE_ENCODED,
		),
	'wrong_answer'=>array (
		'description'=>'Possible wrong answer (separated by |)',
		'required'=>false,
		'filter'=>FILTER_SANITIZE_ENCODED,
		),
	'difficult_level'=>array (
		'description'=>'difficult of the question (0-100) use the following range : 10 very easy, 20 easy, 30 medium, 40 hard, 50 very-hard, &gt;50 impossible',
		'required'=>false,
		'filter' => FILTER_VALIDATE_INT,
		'options'=> array('min_range' => 1, 'max_range' => 100)
		),
	'response_type'=>array (
		'description'=>'response type use: (options = multiple choice, text = free answer)',
		'required'=>false,
		'filter'=>FILTER_SANITIZE_ENCODED,
		),
	'tags'=>array (
		'description'=>'Possible tags of the question, used for sub-categories (separated by |)',
		'required'=>false,
		'filter'=>FILTER_SANITIZE_ENCODED,
		),
	);

$configuration_array = array(
	'title'=>array(
		'value'=>"Rispondi alle domande",
		'description' => 'title of the quiz',
		'changable' => false
		),  
	'Num_options'=>array(
		'value'=> 4,
		'description' => 'Number of options for each question (valid in only multiple choice question)',
		'changable' => true
		),
	'Num_question_per_page'=>array(
		'value'=> 1,
		'description' => 'Number of question for each page (0 means all question in a single page)',
		'changable' => true),  
	'Max_question_total'=>array(
		'value'=> 6,
		'description' => 'Total Number of the questions (0 means all available)',
		'changable' => true
		),  
	'min_diffucult_level'=>array(
		'value'=> 0,
		'description' => 'Minimun difficult of the question (0-100) use the following range : 10 very easy, 20 easy, 30 medium, 40 hard, 50 very-hard, &gt;50 impossible',
		'changable' => true
		), 
	'max_diffucult_level'=>array(
		'value'=> 100,
		'description' => 'Maximum difficult of the question (0-100) use the following range : 10 very easy, 20 easy, 30 medium, 40 hard, 50 very-hard, &gt;50 impossible',
		'changable' => true
		), 
	'default_response_type'=>array(
		'value'=> "options",
		'description' => 'Default response type use: (options = multiple choice, text = free answer) ',
		'changable' => true
		), 
	'default_randomize_question'=>array(
		'value'=> "TRUE",
		'description' => 'Randomize questions',
		'changable' => true
		), 
	'reverse_question'=>array(
		'value'=> "FALSE",
		'description' => 'Reverse question with answer',
		'changable' => true
		), 
	'tags' =>array(
		'value'=> "",
		'description' => 'Filter the quiz with tags (leave empty if you dont want to filter it)',
		'changable' => true
		), 
	'possible_tags' =>array(
		'value'=> "",
		'description' => 'possible tags available for this quiz',
		'changable' => false
		),
	'congratulation_file'=>array(
		'value'=> 'data/conf/congratulation-girl6.csv',
		'description' => 'source data for the image shown if you win the quiz',
		'changable' => false
		),
	'quiz_name'=>array(
		'value'=> 'data/src/test/quiz_prova.csv',
		'description' => 'Dummy quiz name for start the quiz (in case of ods file you can select a sheet: quiz_prova.ods#Sheet2)',
		'changable' => false
		),  

	/* extra conf = 
		

		*/
		//'quiz_configuration']=>"zip://./data/quiz_test.zip#conf.xml";
	);

?>