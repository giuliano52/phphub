DROP TABLE IF EXISTS "quiz";
CREATE TABLE quiz ( id INTEGER PRIMARY KEY AUTOINCREMENT, "quiz_name" CHAR, question CHAR, correct_answer CHAR, response_type CHAR , "wrong_answer" CHAR, "difficult_level" INT, "tags" CHAR);


