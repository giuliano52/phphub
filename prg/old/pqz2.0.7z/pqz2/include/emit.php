<?php

/*
 * Copyright (C) 2014 test01
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

function emit_quiz($starting_question = 0) {
    $option = isset($_REQUEST['option']) ? filter_input(INPUT_GET, 'option') : "";

    echo '
<form action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '" method="get">
<table border="1">
';
    emit_question($starting_question);
    $next_question = $starting_question + 1;
    echo '</table>';
    echo '<input type="hidden" name="starting_question" value="' . $next_question . '"> ';
    echo '<input type="hidden" name="task" value="store_answer"> ';
    echo '<input type="hidden" name="option" value="' . $option . '"> ';
    $all_answered = check_all_answer();
    if ($all_answered == TRUE) {
        echo "<br /><br />\n";
        echo "Hai risposto a tutte le domande: Guarda i ";
        echo '<b><a href="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '?task=results&option=' . $option . '">RISULTATI</a></b>';
    } else {
        echo "\n";
        //	echo '<input type="submit" value="Precedente" Name="Nav">';
        echo '<input type="submit" value="Prossimo" Name="Nav">';
    }
    echo "</form>\n";
}

function emit_question($question_index) {
    // emit code for a single question

    $single_quiz_data = $_SESSION['quiz'][$question_index];

    $answer = isset($single_quiz_data['answered_question']) ? $single_quiz_data['answered_question'] : "";
    echo "<tr><td>\n";
    echo emit_question_status($question_index);
    echo "</td>\n";
    echo "<td>\n";
    echo $single_quiz_data["question"];
    echo "</td>\n";
    echo "<td class=\"possible_answer\">\n";
    $response_type = isset($single_quiz_data['response_type']) ? $single_quiz_data['response_type'] : $_SESSION['default_response_type'];
    if ($response_type == "options") {
        // Multiple Options 
        foreach ($single_quiz_data['possible_answer'] as $key => $possible_answer) {
            $checked = ($answer == $possible_answer) ? " checked " : "";
            echo "\t";
            echo '<input type="radio" name="q_' . $question_index . '" value="' . $key . '" ' . $checked . '>';
            echo $possible_answer;
            echo "<br>\n";
        }
    } else {
        $possible_answer = isset($single_quiz_data['answered_question']) ? $single_quiz_data['answered_question'] : "";
        $opt = "";
        /*
         *     $opt = "tabindex=$tab_index ";
          if ($tab_index == 1)
          $opt .= "autofocus"; */

        echo "<input type=\"text\" name=\"q_$question_index\" value=\"$possible_answer\" $opt >";
    }

    echo "</td></tr>\n";
}

function emit_question_status($question_index) {
    // mostra le domande a cui si è risposto e quelle che mancano
    global $base_img_path;


    $option = isset($_REQUEST['option']) ? filter_input(INPUT_GET, 'option') : "";
    $content = "<table>\n";

    foreach ($_SESSION['quiz'] as $id => $single_question) {
        if ($id == $question_index) {
            $extra_stle = "outline: thin solid black;";
        } else {
            $extra_stle = "";
        }
        $link = "?starting_question=$id&task=go_quiz&option=" . $option;
        $content .= "<tr style=\"$extra_stle\" class=\"question_status\">\n";
        $content .= "\t<td><a href=\"$link\">" . ($id + 1) . "</a></td>";
        $content .= "<td><a href=\"$link\">";
        if (isset($single_question['answered_question'])) {
            $img_name = "$base_img_path/Circle-question-green.png";
        } else {
            $img_name = "$base_img_path/Circle-question-yellow.png";
        }
        $content .= "<img src=\"$img_name\" />";
        $content .= "</a></td><tr>\n";
    }

    $content .= "</table>\n";
    return $content;
}

function emit_results() {
    quiz_check_answer();

    $data_quiz = $_SESSION['quiz'];

    $num_question = count($data_quiz);


    echo '<table border="1">';
    echo '<tr ><td>';
    echo '<table border="1">';
    for ($question_index = 0; $question_index < $num_question; $question_index++) {
        if ($data_quiz[$question_index]['response_type'] == "options") {
            $answer = $data_quiz[$question_index]['possible_answer'][$data_quiz[$question_index]["answered_question"]];
        } else {
            $answer = $data_quiz[$question_index]["answered_question"];
        }
        $correct_answer = $data_quiz[$question_index]["all_correct_answer"][0];
        echo '<tr>';
        echo '<td>' . $data_quiz[$question_index]["question"] . '</td>';

        if ($data_quiz[$question_index]['answer_is_correct']) {
            // Correct answer
            echo '<td style="background-color:green;">';
            echo $answer;
            echo "</td>\n";
        } else {
            // wrong answer
            echo '<td style="background-color:red;">';
            echo "Hai risposto : <b>$answer</b><br />";
            echo "Ma la risposta giusta era: <b>$correct_answer</b><br />";
            echo "</td>\n";
        }
        echo '</tr>';
    }
    echo "</table>\n";
    echo "</td><td style=\"vertical-align:top;\">";
    echo 'hai risposto giusto ' . $_SESSION['quiz_conf']['num_correct_answer'] . ' su ' . $num_question . ' domande';
    if ($_SESSION['quiz_conf']['num_correct_answer'] == $num_question) {

        $csv_file = $_SESSION['quiz_conf']['base_path']['value'] . $_SESSION['quiz_conf']['congratulation_file']['value'];

        if (!file_exists($csv_file)) {
            die("File csv -$csv_file- not found");
        }
        $img = choose_cvs_entry($csv_file);
        echo "<br><img src=\"$img\" width=\"800\"><br>\n";
    }

    echo "</td></tr>";
    echo "</table>";
}

function emit_restart() {
    $option = isset($_REQUEST['option']) ? filter_input(INPUT_GET, 'option') : "";
    echo '<b><a href="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '?task=restart_quiz&option=' . $option . '">RICOMINCIA</a></b>';
    echo '<br><A href="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '?task=choose_quiz&option=' . $option . '">CAMBIA QUIZ</A>';
    echo '<br><A href="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '?task=insert_data_into_quiz&option=' . $option . '">INSERISCI DOMANDE</A>';
}

function emit_choose_quiz($dir) {
    $option = isset($_REQUEST['option']) ? filter_input(INPUT_GET, 'option') : "";

    $content = "<table id=\"fancytable\" style=\"width:500px;\">\n";
    $content .="<tr><th>Type</th><th>Quiz Name</th><th>Options</th></tr>";
    $alt = false;

    $possible_quiz = get_possible_quiz($dir);
    foreach ($possible_quiz as $entry => $type) {
        if ($alt)
            $content .= "<tr>\n";
        else
            $content .= "<tr class=\"alt\">\n";

        if ($type == "dir") {

            $content .= "<td><img src=\"data/img/Blue_folder_seth_yastrov_01.png\" ></td>";
            $content .= "<td><A href=\"" . htmlspecialchars($_SERVER["PHP_SELF"]) . "?option=$option&task=choose_quiz&quiz_dir=$dir/$entry\">$entry</A></td>\n";
            $content .= "<td>&nbsp;</td>";
        } elseif ($type == "file") {

            $filename_without_ext = preg_replace("/\\.[^.\\s]{3,4}$/", "", $entry);
            $content .= "<td>quiz</td>\n";
            $content .= '<td><A href="' . htmlspecialchars($_SERVER["PHP_SELF"]) . "?option=$option&task=reset&quiz_configuration=$dir/$entry\">$filename_without_ext</A></td>\n";
            $content .= '<td><A href="' . htmlspecialchars($_SERVER["PHP_SELF"]) . "?option=$option&task=choose_quiz_advanced&quiz_configuration=" . $dir . '/' . $entry . '">Opzioni Avanzate</A></td>' . "\n";
        }
        $content .= "</tr>\n";
        $alt = !$alt;
    }
    $content .= "</table>\n";
    echo $content;
    //return $content;
}

function get_possible_quiz($dir) {

    // chose a random file from a directory
    $a_dir = array();
    $a_files = array();

    $scanned_directory = array_diff(scandir($dir), array('..', '.'));

    foreach ($scanned_directory as $entry) {
        if (is_dir("$dir/$entry")) {
            $a_dir[$entry] = "dir";
        } else {
            $a_files[$entry] = "file";
        }
    }



    $a_out = array_merge($a_dir, $a_files);

    return $a_out;
}

function emit_choose_quiz_advanced() {

    $configuration_array = $_SESSION['quiz_conf'];
    $content = "";
    $content .= '<form action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '" method="get">';

    $content .= "<table id=\"fancytable\">\n";
    $content .= "<tr><th>Configuration</th><th>Value</th>";

    $alt = false;

    foreach ($configuration_array as $key => $single_configuration) {
        if ($single_configuration['changable']) {
            if ($alt)
                $content .= "<tr>\n";
            else
                $content .= "<tr class=\"alt\">\n";

            $content .= "<td>";
            $content .= $single_configuration['description'];
            $content .= "</td>";
            $content .= "<td>";
            $value = $_SESSION['quiz_conf'][$key]['value'];
            $content .= "<input type=\"text\" name=\"$key\" value=\"$value\">";
            $content .= "</td>";

            $content .= "</tr>\n";
            $alt = !$alt;
        }
    }
    if (isset($_SESSION['possible_tags'])) {
        if ($alt)
            $content .= "<tr>\n";
        else
            $content .= "<tr class=\"alt\">\n";

        $content .= "<td>Available TAGS</td>";
        $content .= "<td>" . $_SESSION['possible_tags'] . "</td>";
    }


    $content .= "</table>\n";

    $content .= '<input type="hidden" name="task" value="reset"><br>' . "\n";
    $content .= '<input type="submit" name="Start Quiz"><br>' . "\n";
    $content .= "</form>";
    echo $content;
    //return $content ;
}

function emit_insert_data_into_quiz() {
    $content = '';
    $alt = false;
    $quiz = new pqz();
    $question_fields = $quiz->question_fields;
    $content .= '<form action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '" method="get">';

    $content .= "<table id=\"fancytable\">\n";
    $content .= "<tr><th width=\"30%\">Field</th><th>Value</th>\n";
    foreach ($question_fields as $field => $filter_type) {
        if ($field != "id") {
            if ($alt)
                $content .= "<tr>\n";
            else
                $content .= "<tr class=\"alt\">\n";
            $content .= "<td>";
            if ($filter_type['required'])
                $content .= "<b>" . $filter_type['description'] . " (*) </b>";
            else
                $content .= $filter_type['description'];
            $content .= "</td>";
            $content .= "<td>";
            $content .= "<input type=\"text\" name=\"$field\" size=\"80\">\n";
            $content .= "</td>";
            $content .= "</tr>\n";
            $alt = !$alt;
        }
    }
    $content .= "</table>\n";
    $content .= '<input type="hidden" name="task" value="insert_field"><br>' . "\n";
    $content .= '<input type="submit" name="insert_field"><br>' . "\n";

    $content .= "</form>";

    $content .= "Field with asterisk (*) are mandatory";
    echo $content;
    //return $content;
}

function emit_header() {
    echo<<<EOT
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="style.css" />
        <title>PQZ</title>
    </head>
    <body>
    
EOT;
}

function emit_footer() {

    global $version;

    echo '<br>';
    echo '<div style="font-size:x-small">Versione :' . $version . '</div>';
    echo "\n</body>\n</html>";
}
